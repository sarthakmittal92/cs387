# CS 387 Outlab 5

- text files to be tested need to be added to 'datadir' folder
- n and k can be given as command line arguments
- by default, spark2.txt has been loaded

Command to run:
```sh
python3 200050129_20d070050_lab5.py --n 3 --k 3
```

If wanting to use Kaggle dataset, run (name is the folder name):
```sh
./run.sh <name>
```