Repositories
https://github.com/AndrewJBateman/pern-stack-auth
https://github.com/rwieruch/minimal-react-webpack-babel-setup

Doubts
https://stackoverflow.com/questions/69068357/link-on-react-not-redirecting
https://stackoverflow.com/questions/43351752/react-router-changes-url-but-not-view
https://stackoverflow.com/questions/54069253/the-usestate-set-method-is-not-reflecting-a-change-immediately
https://stackoverflow.com/questions/54954385/react-useeffect-causing-cant-perform-a-react-state-update-on-an-unmounted-comp
https://stackoverflow.com/questions/59327558/express-session-not-saving-finding-session
https://stackoverflow.com/questions/43002444/make-axios-send-cookies-in-its-requests-automatically
https://stackoverflow.com/questions/43002444/make-axios-send-cookies-in-its-requests-automatically
https://stackoverflow.com/questions/50644976/react-button-onclick-redirect-page
https://stackoverflow.com/questions/21963858/how-to-read-file-to-variable-in-nodejs

Styling
https://stackoverflow.com/questions/55625102/center-align-component-both-vertical-and-horizontal-in-react
https://www.w3schools.com/react/react_css.asp
https://ant.design/docs/react/introduce
https://www.w3schools.com/css/css3_buttons.asp
https://www.w3schools.com/css/css_table_align.asp
https://stackoverflow.com/questions/9140999/how-can-i-insert-vertical-blank-space-into-an-html-document
https://stackoverflow.com/questions/68661649/antd-table-render-properties-inside-and-array-of-objects
https://stackoverflow.com/questions/62152372/changing-column-width-in-react-table